﻿namespace AnyLogicDataServerLib
{
    internal class Deserialize
    {
    }
}